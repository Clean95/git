const btn = document.querySelector('.btn');
const question = document.querySelector('#question');
const questionBox = document.querySelector('.question');
const ans1 = document.querySelector('#ans1');
const ans2 = document.querySelector('#ans2');
const ans3 = document.querySelector('#ans3');
const answer1 = document.querySelector('#answer1');
const answer2 = document.querySelector('#answer2');
const answer3 = document.querySelector('#answer3');
const quiz = document.getElementsByName('quiz');
console.log(quiz);
const key = [
    {
        question: 'Pytanie nr1',
        answer1: 'a1',
        answer2: 'b1',
        answer3: 'c1',
        correct: 'b1'
    },
    {   
        question: 'Pytanie nr2',
        answer1: 'a2',
        answer2: 'b2',
        answer3: 'c2',
        correct: 'a2'
    },
    {   
        question: 'Pytanie nr3',
        answer1: 'a3',
        answer2: 'b3',
        answer3: 'c3',
        correct: 'a3'
    },
];

let questionCounter = 0;
let correctCounter = 0;
const newQuestion = () => {

    question.innerHTML = key[questionCounter].question;
    ans1.innerHTML = key[questionCounter].answer1;
    ans2.innerHTML = key[questionCounter].answer2;
    ans3.innerHTML = key[questionCounter].answer3;

    answer1.value = key[questionCounter].answer1;
    answer2.value = key[questionCounter].answer2;
    answer3.value = key[questionCounter].answer3;
}

btn.addEventListener('click', (e) => {
    e.preventDefault();


if(questionCounter < quiz.length-1){
    quiz.forEach( q => {
        if(q.checked){
            if(q.value == key[questionCounter].correct){
               correctCounter++;
            } 
            questionCounter++;
           
        }
    });
    newQuestion();
}

else {
questionBox.innerHTML = '<h1>koniec! odpowiedziales : ' + correctCounter + ' / ' + quiz.length + '</h1>';


}
})

newQuestion();
