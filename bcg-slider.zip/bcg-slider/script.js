const slides = document.querySelectorAll('.slide');
const leftArrow = document.querySelector('.left-arrow');
const rightArrow = document.querySelector('.right-arrow');

let active = 0;


const renderImg = function() {
    slides.forEach( (s,i) => {
        s.classList.remove('active');
        if(active == i)
        {
            s.classList.add('active');
        }
    })
}

leftArrow.addEventListener('click', function(){
    if(active == 0)
    {
        active = slides.length-1;
    } else {
        active--;
    }
    renderImg();
})

rightArrow.addEventListener('click', function(){
    if(active == slides.length-1)
    {
        active = 0;
    } else {
        active++;
    }
    renderImg();
})

renderImg();